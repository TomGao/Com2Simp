// SplitBillTool.h
