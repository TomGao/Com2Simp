#include "StdAfx.h"
#include "SplitData.h"

CSplitData::CSplitData(void)
{
}

CSplitData::~CSplitData(void)
{
}

void CSplitData::ClearData()
{
	m_dir.Clear();
}