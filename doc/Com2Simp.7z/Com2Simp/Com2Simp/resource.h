//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SplitBillTool.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_EDIT_SRC                    1000
#define IDC_EDIT_DES                    1001
#define IDC_EDIT_CUST                   1002
#define IDC_BUTTON_SRC                  1003
#define IDC_BUTTON_DES                  1004
#define IDC_INFO                        1007
#define IDC_PROGRESS1                   1008
#define IDC_PROCESS_INFO                1009
#define IDC_PERCENT_INFO                1009
#define IDC_COMBO_CV_TYPE               1011
#define IDC_REMARK                      1012
#define IDC_CHECK1                      1013
#define IDC_CHECK_DIR                   1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
